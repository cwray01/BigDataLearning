def say_hello():
    #block belonging to the function
    print 'Hello World!'
#End of the function

say_hello() #call the function
say_hello() #call the function again