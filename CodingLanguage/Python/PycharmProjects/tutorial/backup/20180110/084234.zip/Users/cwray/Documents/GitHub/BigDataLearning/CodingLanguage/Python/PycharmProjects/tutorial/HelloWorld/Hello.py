# Note that print is a function
print ("Hello world")