for i in range(1, 5):
    print(i)
else:
    print('The for loop is over')