while True:
    s = raw_input('Enter somthing:')
    if s == 'quit':
        break
    print'Length of the string is', len(s)
print('Done')